# Student Course Management System

## Aim
To design a relational database schema for a Student Course Management System by creating STUDENT, COURSE, and ENROLLMENT relations and identifying primary and foreign keys.

## Primary Keys
- STUDENT: Student_ID
- COURSE: Course_ID
- ENROLLMENT: Enrollment_ID

## Foreign Keys
- Student_ID -> STUDENT(Student_ID)
- Course_ID -> COURSE(Course_ID)
